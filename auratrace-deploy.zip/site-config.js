window.auraSiteConfig = {
  catalogVersion: '2026-07-24-healthcare-v5',
  useAiPackagingImages: true,
  siteName: 'AuraTrace',
  contactEmail: 'hello@auratrace.co.uk',
  whatsappNumber: '447575630141',
  freeDeliveryThreshold: 30,
  discountCode: 'WELCOME15',
  bankDetails: 'Account name: AuraTrace\nSort code: 00-00-00\nAccount number: 00000000\nReference: Your name + product',
  placeholderImage: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=900&q=80',
  defaultProducts: [
    {
      id: 1001,
      name: 'AuraTrace Suraksha Herbal Tea',
      price: 9.99,
      category: 'Health Care | Tea',
      description: 'Daily herbal tea blend for seasonal wellness and light digestive comfort. Pack size: 100 g tea blend.',
      image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Daily Defense Label',
      benefits: ['Supports seasonal wellness routines.', 'Helps keep digestion calm after meals.']
    },
    {
      id: 1007,
      name: 'AuraTrace Apamarga Kshara Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Herbal tablet support for urinary and cleansing routines. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1584362917165-526a968579e8?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Urinary Balance Label',
      benefits: ['Supports urinary comfort in daily routines.', 'Aids internal cleansing support plans.']
    },
    {
      id: 1008,
      name: 'AuraTrace Apamarga Kshara Tablets 60 (Pack of 2)',
      price: 35.98,
      category: 'Health Care | Tablets',
      description: 'Extended routine value pack. Quantity: 2 x 60 tablets.',
      image: 'https://images.unsplash.com/photo-1584362917165-526a968579e8?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Urinary Balance Label',
      benefits: ['Supports urinary comfort in daily routines.', 'Extended quantity for uninterrupted use.']
    },
    {
      id: 1009,
      name: 'AuraTrace Apamarga Kshara Tablets 60 (Pack of 3)',
      price: 53.97,
      category: 'Health Care | Tablets',
      description: 'Long-cycle wellness pack. Quantity: 3 x 60 tablets.',
      image: 'https://images.unsplash.com/photo-1584362917165-526a968579e8?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Urinary Balance Label',
      benefits: ['Supports urinary comfort in daily routines.', 'Long-cycle value quantity for family use.']
    },
    {
      id: 1011,
      name: 'AuraTrace Arjuna Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Arjuna-based daily support for active lifestyle routines. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Cardio Care Label',
      benefits: ['Traditionally used for heart wellness support.', 'Helps maintain daily vitality balance.']
    },
    {
      id: 1012,
      name: 'AuraTrace Arjuna Tablets 60 (Pack of 2)',
      price: 35.98,
      category: 'Health Care | Tablets',
      description: 'Value pair for uninterrupted usage. Quantity: 2 x 60 tablets.',
      image: 'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Cardio Care Label',
      benefits: ['Traditionally used for heart wellness support.', 'Twin pack helps maintain routine continuity.']
    },
    {
      id: 1013,
      name: 'AuraTrace Arjuna Tablets 60 (Pack of 3)',
      price: 53.97,
      category: 'Health Care | Tablets',
      description: 'Complete monthly stock for regular users. Quantity: 3 x 60 tablets.',
      image: 'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Cardio Care Label',
      benefits: ['Traditionally used for heart wellness support.', 'Three-pack value for long-cycle plans.']
    },
    {
      id: 1014,
      name: 'AuraTrace Ashwagandha Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Adaptogenic ashwagandha tablets for stress and stamina support. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Stress Ease Label',
      benefits: ['Helps support calm stress response.', 'Supports stamina during busy schedules.']
    },
    {
      id: 1015,
      name: 'AuraTrace Ashwagandha Tablets 60 (Pack of 2)',
      price: 35.98,
      category: 'Health Care | Tablets',
      description: 'Dual pack for longer continuity. Quantity: 2 x 60 tablets.',
      image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Stress Ease Label',
      benefits: ['Helps support calm stress response.', 'Dual pack for uninterrupted usage.']
    },
    {
      id: 1016,
      name: 'AuraTrace Ashwagandha Tablets 60 (Pack of 3)',
      price: 53.97,
      category: 'Health Care | Tablets',
      description: 'Extended supply for structured routines. Quantity: 3 x 60 tablets.',
      image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Stress Ease Label',
      benefits: ['Helps support calm stress response.', 'Long-term pack for structured wellness cycles.']
    },
    {
      id: 1017,
      name: 'AuraTrace Ashwagandha Tablets 60 + Ayush Kwath 100 g',
      price: 27.99,
      category: 'Health Care | Immunity Combo',
      description: 'Stress and seasonal support combo. Quantity: 60 tablets + 100 g kwath blend.',
      image: 'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Immunity Duo Label',
      benefits: ['Supports stress balance and immunity routines.', 'Combo format improves daily consistency.']
    },
    {
      id: 1018,
      name: 'AuraTrace Brahmi Tablets 30',
      price: 10.0,
      category: 'Health Care | Tablets',
      description: 'Brahmi formulation for focus and mental clarity routines. Quantity: 30 tablets.',
      image: 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Focus Support Label',
      benefits: ['Supports focus during study or work.', 'Helps maintain mental clarity daily.']
    },
    {
      id: 1019,
      name: 'AuraTrace Brahmi Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Extended Brahmi support for study and work cycles. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Focus Support Label',
      benefits: ['Supports focus during study or work.', '60-tablet size for longer routines.']
    },
    {
      id: 1020,
      name: 'AuraTrace Giloy Tablets 30',
      price: 10.0,
      category: 'Health Care | Tablets',
      description: 'Giloy tablets for daily resilience support. Quantity: 30 tablets.',
      image: 'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Resilience Label',
      benefits: ['Supports natural immune resilience.', 'Useful for everyday wellness plans.']
    },
    {
      id: 1021,
      name: 'AuraTrace Giloy Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Higher count giloy format for routine usage. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Resilience Label',
      benefits: ['Supports natural immune resilience.', 'Higher quantity supports long-term use.']
    },
    {
      id: 1022,
      name: 'AuraTrace Power Plus Tablets 30',
      price: 10.0,
      category: 'Health Care | Tablets',
      description: 'Daily vitality support in a compact 30-tablet pack. Quantity: 30 tablets.',
      image: 'https://images.unsplash.com/photo-1543362906-acfc16c67564?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Vitality Label',
      benefits: ['Supports daily energy and stamina.', 'Compact 30-tablet starter quantity.']
    },
    {
      id: 1023,
      name: 'AuraTrace Pustihar Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Comprehensive wellness support formula. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1585435557343-3b092031a831?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Nourish Label',
      benefits: ['Supports daily nourishment and strength.', 'Balanced formula for regular routines.']
    },
    {
      id: 1024,
      name: 'AuraTrace Sugar Fit Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Herbal blood-sugar support blend for daily wellness plans. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1579154204601-01588f351e67?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Metabolic Balance Label',
      benefits: ['Supports metabolic wellness routines.', 'Helps maintain day-to-day balance.']
    },
    {
      id: 1025,
      name: 'AuraTrace Slim Rattan Tablets 30',
      price: 10.0,
      category: 'Health Care | Tablets',
      description: 'Weight-management support with appetite and metabolism focus. Quantity: 30 tablets.',
      image: 'https://images.unsplash.com/photo-1494390248081-4e521a5940db?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Lean Support Label',
      benefits: ['Supports appetite and weight goals.', 'Helps maintain active lifestyle routines.']
    },
    {
      id: 1026,
      name: 'AuraTrace Slim Rattan Granules 200 g',
      price: 13.99,
      category: 'Health Care | Granules',
      description: 'Convenient granule format for weight routine support. Quantity: 200 g.',
      image: 'https://images.unsplash.com/photo-1514995669114-6081e934b693?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Lean Support Label',
      benefits: ['Supports weight-management routines.', 'Granule format blends easily into plans.']
    },
    {
      id: 1027,
      name: 'AuraTrace Madhumay Rakshak Granules 200 g',
      price: 13.99,
      category: 'Health Care | Granules',
      description: 'Granule blend designed for glucose and metabolic balance plans. Quantity: 200 g.',
      image: 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Metabolic Balance Label',
      benefits: ['Supports glucose-aware daily routines.', 'Granule format for flexible intake.']
    },
    {
      id: 1029,
      name: 'AuraTrace Dard Rakshak Tablets 30',
      price: 10.0,
      category: 'Health Care | Tablets',
      description: 'Pain-relief support tablets with herb-inspired anti-inflammatory profile. Quantity: 30 tablets.',
      image: 'https://images.unsplash.com/photo-1570554886111-e80fcca6a029?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Joint Comfort Label',
      benefits: ['Supports comfort for active joints.', 'Helps maintain movement with ease.']
    },
    {
      id: 1030,
      name: 'AuraTrace Dard Rakshak Oil 100 ml',
      price: 8.99,
      category: 'Health Care | Oil',
      description: 'Topical wellness oil for muscle and joint comfort routines. Quantity: 100 ml.',
      image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Topical Relief Label',
      benefits: ['Supports local muscle relaxation.', 'Helps soothe stiffness after activity.']
    },
    {
      id: 1032,
      name: 'AuraTrace Gynae Plus Tablets 60',
      price: 17.99,
      category: 'Health Care | Tablets',
      description: 'Women wellness support formulation for balance and vitality. Quantity: 60 tablets.',
      image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Women Wellness Label',
      benefits: ['Supports women wellness balance routines.', 'Helps maintain daily vitality support.']
    },
    {
      id: 1033,
      name: 'AuraTrace Ayush Kwath 100 g',
      price: 9.49,
      category: 'Health Care | Kwath',
      description: 'Classical herbal decoction mix for seasonal and respiratory support. Quantity: 100 g.',
      image: 'https://images.unsplash.com/photo-1597318038660-033ff2f8f0b0?auto=format&fit=crop&w=900&q=80',
      labelSeries: 'Seasonal Guard Label',
      benefits: ['Supports respiratory comfort in seasonal changes.', 'Classic kwath profile for daily use.']
    }
  ]
};
