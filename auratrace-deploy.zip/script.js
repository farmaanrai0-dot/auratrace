const themeToggle = document.querySelector('.theme-toggle');
const menuToggle = document.querySelector('.menu-toggle');
const siteNav = document.getElementById('site-nav');
const productList = document.getElementById('product-list');
const productForm = document.getElementById('product-form');
const imagePreview = document.getElementById('product-image-preview');
const cartItems = document.getElementById('cart-items');
const cartSubtotal = document.getElementById('cart-subtotal');
const deliveryNote = document.getElementById('delivery-note');
const clearCartButton = document.getElementById('clear-cart');
const checkoutForm = document.getElementById('checkout-form');
const checkoutStatus = document.getElementById('checkout-status');
const checkoutWhatsapp = document.getElementById('checkout-whatsapp');
const checkoutEmail = document.getElementById('checkout-email');
const bankDetails = document.getElementById('bank-details');

const config = window.auraSiteConfig || {};
const freeDeliveryThreshold = Number(config.freeDeliveryThreshold || 30);
const catalogVersion = String(config.catalogVersion || 'v1');

const initialProducts = Array.isArray(config.defaultProducts) ? config.defaultProducts : [];
const storedCatalogVersion = localStorage.getItem('aura-catalog-version');
let products = JSON.parse(localStorage.getItem('aura-products') || 'null') || initialProducts;

if (storedCatalogVersion !== catalogVersion) {
  products = initialProducts;
  localStorage.setItem('aura-products', JSON.stringify(initialProducts));
  localStorage.setItem('aura-catalog-version', catalogVersion);
}
let cart = JSON.parse(localStorage.getItem('aura-cart') || '[]');
let orders = JSON.parse(localStorage.getItem('aura-orders') || '[]');

const preferredTheme = localStorage.getItem('aura-theme') || 'light';
document.body.setAttribute('data-theme', preferredTheme);

if (themeToggle) {
  themeToggle.textContent = preferredTheme === 'light' ? 'Dark mode' : 'Light mode';
  themeToggle.addEventListener('click', () => {
    const nextTheme = document.body.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    document.body.setAttribute('data-theme', nextTheme);
    localStorage.setItem('aura-theme', nextTheme);
    themeToggle.textContent = nextTheme === 'light' ? 'Dark mode' : 'Light mode';
  });
}

if (menuToggle && siteNav) {
  menuToggle.addEventListener('click', () => {
    const open = siteNav.classList.toggle('mobile-open');
    menuToggle.setAttribute('aria-expanded', String(open));
  });
}

if (bankDetails) {
  bankDetails.textContent = config.bankDetails || 'Bank details will appear here.';
}

function persistProducts() {
  localStorage.setItem('aura-products', JSON.stringify(products));
}

function persistCart() {
  localStorage.setItem('aura-cart', JSON.stringify(cart));
}

function persistOrders() {
  localStorage.setItem('aura-orders', JSON.stringify(orders));
}

function currency(value) {
  return `£${Number(value || 0).toFixed(2)}`;
}

function parsePackCount(name = '') {
  const match = String(name).match(/pack of\s*(\d+)/i);
  if (!match) {
    return 1;
  }

  return Math.max(1, Number(match[1] || 1));
}

function herbMetaForProduct(product) {
  const name = String(product.name || '').toLowerCase();
  const category = String(product.category || '').toLowerCase();
  const herbLibrary = {
    ashwagandha: {
      label: 'Ashwagandha',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/WithaniaFruit.jpg/960px-WithaniaFruit.jpg'
    },
    brahmi: {
      label: 'Brahmi',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Starr_010818-0007_Bacopa_monnieri.jpg/640px-Starr_010818-0007_Bacopa_monnieri.jpg'
    },
    giloy: {
      label: 'Giloy',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Tinospora_cordifolia.jpg/960px-Tinospora_cordifolia.jpg'
    },
    arjuna: {
      label: 'Arjuna',
      image: 'https://upload.wikimedia.org/wikipedia/commons/9/94/Fruit_I_IMG_9577.jpg'
    },
    tulsi: {
      label: 'Tulsi',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Tulsi_or_Tulasi_Holy_basil.jpg/640px-Tulsi_or_Tulasi_Holy_basil.jpg'
    },
    shatavari: {
      label: 'Shatavari',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Asparagus_racemosus.JPG/640px-Asparagus_racemosus.JPG'
    },
    apamarga: {
      label: 'Apamarga',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Achyranthes_aspera_02.JPG/640px-Achyranthes_aspera_02.JPG'
    },
    blend: {
      label: 'Herbal Blend',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Tulsi_or_Tulasi_Holy_basil.jpg/640px-Tulsi_or_Tulasi_Holy_basil.jpg'
    }
  };

  if (name.includes('ashwagandha')) return herbLibrary.ashwagandha;
  if (name.includes('brahmi')) return herbLibrary.brahmi;
  if (name.includes('giloy')) return herbLibrary.giloy;
  if (name.includes('arjuna')) return herbLibrary.arjuna;
  if (name.includes('apamarga')) return herbLibrary.apamarga;
  if (name.includes('gynae') || name.includes('pustihar')) return herbLibrary.shatavari;
  if (name.includes('sugar') || name.includes('madhumay')) return herbLibrary.giloy;
  if (name.includes('suraksha') || name.includes('kwath')) return herbLibrary.tulsi;
  if (name.includes('dard') || name.includes('slim') || name.includes('power')) return herbLibrary.blend;
  if (category.includes('tablet') || category.includes('oil') || category.includes('granule') || category.includes('tea')) return herbLibrary.blend;

  return herbLibrary.blend;
}

function aiBottlePrompt(product) {
  const herb = herbMetaForProduct(product);
  const packCount = parsePackCount(product.name);
  const packPhrase = packCount > 1 ? `${packCount} bottles` : '1 bottle';

  return [
    `Photorealistic ecommerce studio product photo of ${packPhrase}, identical white herbal supplement bottle with white cap.`,
    'Brand on label: AuraTrace.',
    `Label must include a small real ${herb.label} herb image printed on the container.`,
    'Front-facing packshot, clean white background, natural soft shadow, high detail.',
    'Bottle shape and cap design must remain exactly consistent across all products.',
    'No mugs, no cups, no jars, no food bowls, no human hands, no random props.'
  ].join(' ');
}

function aiBottleImageUrl(product) {
  const prompt = aiBottlePrompt(product);
  const seed = Number(product.id || 1) % 100000;
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&seed=${seed}&nologo=true`;
}

function escapeSvgText(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function herbThumbFallbackUrl(label = 'Herb') {
  const safeLabel = escapeSvgText(label);
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#eef6eb"/>
          <stop offset="100%" stop-color="#d7e7cf"/>
        </linearGradient>
      </defs>
      <rect width="80" height="80" rx="14" fill="url(#bg)"/>
      <path d="M24 50c0-12 10-22 22-22 0 12-10 22-22 22Z" fill="#5c7f52"/>
      <path d="M38 26c6 8 8 17 5 26" stroke="#35573a" stroke-width="2" fill="none"/>
      <text x="40" y="70" text-anchor="middle" font-family="Arial, sans-serif" font-size="9" fill="#2f4231">${safeLabel}</text>
    </svg>
  `;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function bottleFallbackImageUrl(product) {
  const herb = herbMetaForProduct(product);
  const packCount = Math.min(parsePackCount(product.name), 3);
  const shortName = String(product.name || 'AuraTrace Herbal')
    .replace(/^AuraTrace\s*/i, '')
    .replace(/\(.*\)/g, '')
    .trim()
    .slice(0, 26);

  const bottleX = packCount === 1 ? [180] : packCount === 2 ? [135, 225] : [95, 180, 265];
  const bottles = bottleX.map((x) => `
      <g transform="translate(${x},80)">
        <rect x="-8" y="0" width="16" height="26" rx="5" fill="#ffffff" stroke="#d6dbe0"/>
        <rect x="-42" y="18" width="84" height="138" rx="18" fill="#ffffff" stroke="#d4d7db"/>
        <rect x="-36" y="56" width="72" height="72" rx="10" fill="#f9f8f2" stroke="#d6ccb0"/>
        <text x="0" y="78" text-anchor="middle" font-family="Arial, sans-serif" font-size="9" fill="#51644a">AuraTrace</text>
        <text x="0" y="92" text-anchor="middle" font-family="Arial, sans-serif" font-size="8" fill="#2f4130">${escapeSvgText(herb.label)}</text>
        <text x="0" y="106" text-anchor="middle" font-family="Arial, sans-serif" font-size="7" fill="#5d625b">${escapeSvgText(shortName)}</text>
      </g>
  `).join('');

  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="360" height="320" viewBox="0 0 360 320">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#ffffff"/>
          <stop offset="100%" stop-color="#f2f4f6"/>
        </linearGradient>
      </defs>
      <rect width="360" height="320" fill="url(#bg)"/>
      <ellipse cx="180" cy="272" rx="112" ry="18" fill="#dfe4e7"/>
      ${bottles}
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function resolveProductImage(product) {
  const img = String(product.image || '').trim();
  if (img.startsWith('data:image/')) {
    return img;
  }

  if (config.useAiPackagingImages) {
    return aiBottleImageUrl(product);
  }

  return bottleFallbackImageUrl(product);
}

function quantityFromDescription(description = '') {
  const text = String(description);
  const quantityMatch = text.match(/Quantity:\s*([^.]*)/i);
  if (quantityMatch && quantityMatch[1]) {
    return quantityMatch[1].trim();
  }

  const packMatch = text.match(/Pack size:\s*([^.]*)/i);
  if (packMatch && packMatch[1]) {
    return packMatch[1].trim();
  }

  return 'See product details';
}

function shelfLifeFromCategory(category = '') {
  const normalized = String(category).toLowerCase();
  if (normalized.includes('oil')) {
    return '24 months from MFG';
  }

  if (normalized.includes('tablet')) {
    return '36 months from MFG';
  }

  if (normalized.includes('tea') || normalized.includes('kwath') || normalized.includes('granule')) {
    return '24 months from MFG';
  }

  return '24 months from MFG';
}

function usageLineFromCategory(category = '') {
  const normalized = String(category).toLowerCase();
  if (normalized.includes('oil')) {
    return 'Use: Apply 3-5 drops topically and massage 1-2 times daily.';
  }

  if (normalized.includes('tablet')) {
    return 'Use: 1 tablet twice daily after meals, or as advised by a practitioner.';
  }

  if (normalized.includes('tea')) {
    return 'Use: Steep 1 tsp in hot water for 3-5 min, once or twice daily.';
  }

  if (normalized.includes('kwath')) {
    return 'Use: Boil 1 tsp with water and drink warm once daily.';
  }

  if (normalized.includes('granule')) {
    return 'Use: 1 tsp with warm water after meals, once or twice daily.';
  }

  return 'Use: Follow on-pack guidance or practitioner advice.';
}

function buildLabelMeta(product) {
  const now = new Date();
  const mfg = now.toLocaleString('en-GB', { month: 'short', year: 'numeric' });
  const codeBits = String(product.name || 'AT')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter((word) => word && word !== 'AURATRACE')
    .slice(0, 3)
    .map((word) => word[0])
    .join('');

  return {
    sku: `AT-${codeBits || 'PRD'}-${product.id}`,
    batch: `AT${String(now.getFullYear()).slice(-2)}${String(product.id).slice(-4)}`,
    netQuantity: quantityFromDescription(product.description),
    mfg,
    shelfLife: shelfLifeFromCategory(product.category),
    usage: usageLineFromCategory(product.category),
    storage: 'Storage: Keep in a cool, dry place away from direct sunlight.'
  };
}

function cartSubtotalValue() {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function buildOrderLinks() {
  const subtotal = cartSubtotalValue();
  const summary = cart.length
    ? cart.map((item) => `${item.name} x${item.quantity} - ${currency(item.price * item.quantity)}`).join(', ')
    : 'No products selected yet';
  const message = `Hello AuraTrace, I would like help with this order: ${summary}. Subtotal: ${currency(subtotal)}.`;

  if (checkoutWhatsapp) {
    checkoutWhatsapp.href = `https://wa.me/${config.whatsappNumber || '447575630141'}?text=${encodeURIComponent(message)}`;
  }

  if (checkoutEmail) {
    checkoutEmail.href = `mailto:${config.contactEmail || 'hello@auratrace.co.uk'}?subject=${encodeURIComponent('AuraTrace order support')}&body=${encodeURIComponent(message)}`;
  }
}

function updateDeliveryNote(subtotal) {
  if (!deliveryNote) {
    return;
  }

  if (subtotal === 0) {
    deliveryNote.textContent = `Spend ${currency(freeDeliveryThreshold)} more to unlock free delivery.`;
    return;
  }

  if (subtotal >= freeDeliveryThreshold) {
    deliveryNote.textContent = 'Free delivery unlocked for this basket.';
    return;
  }

  deliveryNote.textContent = `Spend ${currency(freeDeliveryThreshold - subtotal)} more to unlock free delivery.`;
}

function renderCart() {
  if (!cartItems || !cartSubtotal) {
    return;
  }

  cartItems.innerHTML = '';

  if (cart.length === 0) {
    cartItems.innerHTML = '<p class="empty-copy">Your cart is empty. Add products when you are ready.</p>';
    cartSubtotal.textContent = currency(0);
    updateDeliveryNote(0);
    buildOrderLinks();
    return;
  }

  cart.forEach((item) => {
    const article = document.createElement('article');
    article.className = 'cart-item';
    article.innerHTML = `
      <div>
        <h4>${item.name}</h4>
        <div class="cart-item-meta">
          <span>${item.category}</span>
          <span>Qty ${item.quantity}</span>
          <span>${currency(item.price)} each</span>
        </div>
      </div>
      <div class="cart-item-price">
        <strong>${currency(item.price * item.quantity)}</strong>
        <button class="icon-button" type="button" data-remove-id="${item.id}">Remove</button>
      </div>
    `;
    cartItems.appendChild(article);
  });

  const subtotal = cartSubtotalValue();
  cartSubtotal.textContent = currency(subtotal);
  updateDeliveryNote(subtotal);
  buildOrderLinks();
}

function addToCart(productId) {
  const product = products.find((item) => String(item.id) === String(productId));
  if (!product) {
    return;
  }

  const existing = cart.find((item) => String(item.id) === String(productId));
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.unshift({
      id: product.id,
      name: product.name,
      category: product.category,
      price: product.price,
      quantity: 1
    });
  }

  persistCart();
  renderCart();
}

function removeFromCart(productId) {
  cart = cart.filter((item) => String(item.id) !== String(productId));
  persistCart();
  renderCart();
}

function renderProducts() {
  if (!productList) {
    return;
  }

  productList.innerHTML = '';

  if (products.length === 0) {
    productList.innerHTML = `
      <article class="product-card empty-state-card">
        <p class="eyebrow">COLLECTION COMING SOON</p>
        <h4>Your storefront is ready for products.</h4>
        <p>Add products in the section below and they will appear here with price, category, and add-to-cart controls.</p>
      </article>
    `;
    return;
  }

  products.forEach((product) => {
    const labelSeries = String(product.labelSeries || 'Botanical Standard Label').trim();
    const benefits = Array.isArray(product.benefits) && product.benefits.length
      ? product.benefits.slice(0, 2)
      : ['Traditionally used in everyday wellness routines.', 'Use consistently as part of a balanced lifestyle.'];
    const herbMeta = herbMetaForProduct(product);
    const labelMeta = buildLabelMeta(product);
    const productImageUrl = resolveProductImage(product);
    const productFallbackImageUrl = bottleFallbackImageUrl(product);
    const herbThumbUrl = String(herbMeta.image || '').trim() || herbThumbFallbackUrl(herbMeta.label);
    const herbThumbFallback = herbThumbFallbackUrl(herbMeta.label);
    const card = document.createElement('article');
    card.className = 'product-card';
    card.innerHTML = `
      <img class="product-image" src="${productImageUrl}" data-fallback-src="${productFallbackImageUrl}" alt="${product.name}" loading="lazy" />
      <div class="product-label" aria-label="AuraTrace custom label">
        <div class="label-head">
          <div class="label-brand-group">
            <img class="label-herb-thumb" src="${herbThumbUrl}" data-fallback-src="${herbThumbFallback}" alt="${herbMeta.label} herb" loading="lazy" />
            <p class="label-brand">AuraTrace</p>
          </div>
          <span class="label-badge">Custom label</span>
        </div>
        <p class="label-series">${labelSeries}</p>
        <div class="label-specs">
          <span>SKU: ${labelMeta.sku}</span>
          <span>Batch: ${labelMeta.batch}</span>
          <span>Net qty: ${labelMeta.netQuantity}</span>
          <span>MFG: ${labelMeta.mfg}</span>
          <span>Shelf life: ${labelMeta.shelfLife}</span>
        </div>
        <p class="label-use">${labelMeta.usage}</p>
        <p class="label-storage">${labelMeta.storage}</p>
        <ul class="label-benefits">
          <li>${benefits[0] || ''}</li>
          <li>${benefits[1] || ''}</li>
        </ul>
      </div>
      <div class="product-top">
        <div>
          <p class="eyebrow">${product.category}</p>
          <h4>${product.name}</h4>
        </div>
        <span class="product-price">${currency(product.price)}</span>
      </div>
      <p>${product.description}</p>
      <div class="tag-row">
        <span>Premium</span>
        <span>Shop ready</span>
        <span>Cart enabled</span>
      </div>
      <div class="product-actions">
        <button class="btn btn-primary" type="button" data-add-id="${product.id}">Add to cart</button>
        <a class="btn btn-secondary" href="https://wa.me/${config.whatsappNumber || '447575630141'}?text=${encodeURIComponent(`Hello AuraTrace, I have a question about ${product.name}.`) }" target="_blank" rel="noreferrer">Ask about this</a>
      </div>
    `;

    const productImageElement = card.querySelector('.product-image');
    if (productImageElement) {
      productImageElement.addEventListener('error', () => {
        const fallbackSrc = productImageElement.getAttribute('data-fallback-src');
        if (fallbackSrc && productImageElement.src !== fallbackSrc) {
          productImageElement.src = fallbackSrc;
        }
      });
    }

    const herbThumbElement = card.querySelector('.label-herb-thumb');
    if (herbThumbElement) {
      herbThumbElement.addEventListener('error', () => {
        const fallbackSrc = herbThumbElement.getAttribute('data-fallback-src');
        if (fallbackSrc && herbThumbElement.src !== fallbackSrc) {
          herbThumbElement.src = fallbackSrc;
        }
      });
    }

    productList.appendChild(card);
  });
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      resolve('');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Unable to read image file.'));
    reader.readAsDataURL(file);
  });
}

if (productForm) {
  productForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const formData = new FormData(productForm);
    const imageFile = formData.get('image');

    const product = {
      id: Date.now(),
      name: String(formData.get('name') || '').trim(),
      price: Number(formData.get('price') || 0),
      category: String(formData.get('category') || '').trim(),
      description: String(formData.get('description') || '').trim(),
      image: imageFile && typeof imageFile !== 'string' ? await readFileAsDataUrl(imageFile) : '',
      labelSeries: 'Custom AuraTrace Label',
      benefits: ['Supports routine wellness goals.', 'Use daily as advised for best consistency.']
    };

    if (!product.name || !product.category || !product.description || product.price <= 0) {
      return;
    }

    products = [product, ...products];
    persistProducts();
    renderProducts();
    productForm.reset();

    if (imagePreview) {
      imagePreview.textContent = `${product.name} added to the storefront.`;
    }
  });
}

if (productList) {
  productList.addEventListener('click', (event) => {
    const addButton = event.target.closest('[data-add-id]');
    if (!addButton) {
      return;
    }

    addToCart(addButton.getAttribute('data-add-id'));
  });
}

if (cartItems) {
  cartItems.addEventListener('click', (event) => {
    const removeButton = event.target.closest('[data-remove-id]');
    if (!removeButton) {
      return;
    }

    removeFromCart(removeButton.getAttribute('data-remove-id'));
  });
}

if (clearCartButton) {
  clearCartButton.addEventListener('click', () => {
    cart = [];
    persistCart();
    renderCart();
  });
}

if (checkoutForm) {
  checkoutForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const formData = new FormData(checkoutForm);
    const order = {
      id: Date.now(),
      items: cart,
      subtotal: cartSubtotalValue(),
      customerName: String(formData.get('customerName') || '').trim(),
      customerEmail: String(formData.get('customerEmail') || '').trim(),
      customerPhone: String(formData.get('customerPhone') || '').trim(),
      deliveryAddress: String(formData.get('deliveryAddress') || '').trim(),
      paymentMethod: String(formData.get('paymentMethod') || '').trim(),
      notes: String(formData.get('notes') || '').trim(),
      createdAt: new Date().toISOString()
    };

    orders = [order, ...orders];
    persistOrders();

    if (checkoutStatus) {
      checkoutStatus.textContent = `${order.customerName || 'Customer'}'s order request has been saved. Use WhatsApp or email buttons to complete the purchase conversation.`;
    }

    const orderLines = cart.length
      ? cart.map((item) => `${item.name} x${item.quantity}`).join(', ')
      : 'No items currently in cart';
    const message = `Hello AuraTrace, my order request is saved. Items: ${orderLines}. Payment preference: ${order.paymentMethod}. Name: ${order.customerName}.`;

    if (checkoutWhatsapp) {
      checkoutWhatsapp.href = `https://wa.me/${config.whatsappNumber || '447575630141'}?text=${encodeURIComponent(message)}`;
    }

    if (checkoutEmail) {
      checkoutEmail.href = `mailto:${config.contactEmail || 'hello@auratrace.co.uk'}?subject=${encodeURIComponent('Saved AuraTrace order request')}&body=${encodeURIComponent(message)}`;
    }

    checkoutForm.reset();
  });
}

renderProducts();
renderCart();
buildOrderLinks();
